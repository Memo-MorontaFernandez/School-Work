<?php

require("mysql_connect.php");

// Get cd_id
$cd_id = $_GET['cd_id'];

// DEFAULT QUERY: RETRIEVE EVERYTHING
$result = mysqli_query($con,"SELECT * FROM cd_catalog_class WHERE cd_id = '$cd_id' ") or die (mysql_error());

/************************** ECHO OUT YOUR RESULTS ***********************/
while ($row = mysqli_fetch_array($result)) {
	$cd_id = ($row['cd_id']);
	$artist = ($row['artist']);
	$title = ($row['title']);
	$year = ($row['year']);
	$genre = ($row['genre']);
	$label = ($row['label']);
	$artwork = $row['artwork'];
	$description = nl2br($row['description']);
	$soundclip = $row['soundclip'];
	echo "<div class=\"thisCD\">\n";

	echo "<img src=\"artwork/thumbs100/$artwork\" class=\"cdImage\" />";

	echo "<span class=\"displayCategory\">Title:</span> <span class=\"displayInfo\">". $title ."</span><br />\n";
	echo "<span class=\"displayCategory\">Artist:</span> <span class=\"displayInfo\">". $artist ."</span><br />\n";
	echo "<span class=\"displayCategory\">Year:</span> <span class=\"displayInfo\">". $year ."</span><br />\n";
	echo "<span class=\"displayCategory\">Label:</span> <span class=\"displayInfo\">". $label ."</span><br />\n";
	echo "<span class=\"displayCategory\">Description:</span> <span class=\"displayInfo\">". $description ."</span><br />\n";
	echo "<span class=\"displayCategory\">Sound Clip:</span> <span class=\"displayInfo\">". $soundclip ."</span><br />\n";
	echo "<a href=\"display.php\">Back Home</a><br />";
	
echo "<div class=\"clearFix\"></div>\n";
echo "\n</div>\n";
}